#!/bin/bash
# Entrypoint for VPS container - starts tmate and posts SSH string to panel
set -e
# ensure tmate available
if ! command -v tmate >/dev/null 2>&1; then
  apt-get update && apt-get install -y tmate curl || true
fi

# start tmate and post session info
tmate -S /tmp/tmate.sock new-session -d
sleep 2
SSH_CMD=$(tmate -S /tmp/tmate.sock display -p '#{tmate_ssh}')
WEB_CMD=$(tmate -S /tmp/tmate.sock display -p '#{tmate_web}')
# Post to panel - TMATE_CALLBACK_SECRET must be provided as env var in container run
if [ -n "$TMATE_CALLBACK_SECRET" ] && [ -n "$SERVER_URL" ] ; then
  curl -s -X POST "$SERVER_URL/vps/ssh-update" -H "Content-Type: application/json" -H "x-tmate-secret: $TMATE_CALLBACK_SECRET" -d '{ "container": "'"$(hostname)"'", "ssh": "'"$SSH_CMD"'", "web": "'"$WEB_CMD"'" }' || true
fi

# keep container running (user can open shell via tmate)
# run a shell
exec /bin/bash -l
