#!/usr/bin/env node
// Usage: node scripts/admin-create.js admin@example.com password
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const User = require('../models/User');
const argv = process.argv.slice(2);
if(argv.length < 2){ console.log('Usage: node scripts/admin-create.js email password'); process.exit(1); }
const email = argv[0], password = argv[1];
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/zothynodes').then(async ()=>{
  const hash = await bcrypt.hash(password, 10);
  const u = await User.create({ email, passwordHash: hash, role: 'admin' });
  console.log('Admin created:', u.email, u._id);
  process.exit(0);
}).catch(err=>{ console.error(err); process.exit(1); });
