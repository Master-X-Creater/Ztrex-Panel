const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const VPSSchema = new Schema({
  name: String,
  ownerId: { type: Schema.Types.ObjectId, ref: 'User' },
  containerName: String,
  cpu: Number,
  ram: Number, // in GB
  tag: String,
  status: String,
  ssh: String,
  sshWeb: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('VPS', VPSSchema);
