# ZothyNodes - Docker-based VPS Panel (Prototype)

This is a simplified prototype of ZothyNodes that uses Docker containers as "VPS" instances and tmate for ephemeral SSH access.
The UI is server-rendered EJS templates and backend is Node.js + Express + MongoDB.

## Quick start (development)

1. Copy `.env.example` to `.env` and edit values.
2. Build the VPS Docker image:
   ```bash
   ./install.sh
   ```
3. Start MongoDB (or use your own). Ensure `MONGO_URI` points to it.
4. Create an admin user (run on server):
   ```bash
   node scripts/admin-create.js admin@example.com StrongPassword123
   ```
5. Run the panel:
   ```bash
   npm start
   ```
6. Open `http://localhost:3000` in your browser. Register a normal user or login as admin.

## How it works
- When a container starts it runs `entrypoint.sh`, which starts `tmate` and posts the SSH string to the panel at `/vps/ssh-update` using the shared `TMATE_CALLBACK_SECRET` header.
- The panel lists VPS and shows the `ssh xxxxxx@nyc2.tmate.io` string.

## Notes & Security
- This is a prototype. For production, secure the callback with mTLS or signed tokens, use a proper session system, and harden Docker usage.
- Containers run with `--env TMATE_CALLBACK_SECRET` so they can authenticate the callback.

