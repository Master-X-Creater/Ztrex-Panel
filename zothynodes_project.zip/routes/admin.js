const express = require('express');
const router = express.Router();
const User = require('../models/User');
const jwt = require('jsonwebtoken');

function getUserFromReq(req){
  const token = req.cookies && req.cookies.ztoken;
  if(!token) return null;
  try{ return jwt.verify(token, process.env.JWT_SECRET || 'dev'); }catch(e){ return null; }
}

router.get('/users', async (req,res)=>{
  const user = getUserFromReq(req); if(!user || user.role !== 'admin') return res.redirect('/auth/login');
  const users = await User.find();
  res.render('admin_users', { users });
});

router.post('/users/:id/suspend', async (req,res)=>{
  const user = getUserFromReq(req); if(!user || user.role !== 'admin') return res.redirect('/auth/login');
  await User.updateOne({ _id: req.params.id }, { isSuspended: true });
  res.redirect('/admin/users');
});

router.post('/users/:id/block', async (req,res)=>{
  const user = getUserFromReq(req); if(!user || user.role !== 'admin') return res.redirect('/auth/login');
  await User.updateOne({ _id: req.params.id }, { isBlocked: true });
  res.redirect('/admin/users');
});

router.post('/users/:id/delete', async (req,res)=>{
  const user = getUserFromReq(req); if(!user || user.role !== 'admin') return res.redirect('/auth/login');
  await User.deleteOne({ _id: req.params.id });
  res.redirect('/admin/users');
});

module.exports = router;
