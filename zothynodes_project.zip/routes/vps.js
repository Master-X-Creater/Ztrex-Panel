const express = require('express');
const router = express.Router();
const { exec } = require('child_process');
const VPS = require('../models/VPS');
const User = require('../models/User');
const jwt = require('jsonwebtoken');

// simple auth helper (reads cookie)
function getUserFromReq(req){
  const token = req.cookies && req.cookies.ztoken;
  if(!token) return null;
  try{ return jwt.verify(token, process.env.JWT_SECRET || 'dev'); }catch(e){ return null; }
}

// list for logged-in users
router.get('/list', async (req,res) => {
  const user = getUserFromReq(req);
  if(!user) return res.redirect('/auth/login');
  const vps = await VPS.find(user.role === 'admin' ? {} : { ownerId: user.userId });
  return res.render('vps_list', { vps, user });
});

// create form
router.get('/create', async (req,res) => {
  const user = getUserFromReq(req); if(!user) return res.redirect('/auth/login');
  res.render('vps_create');
});

// create action (runs docker)
router.post('/create', async (req,res) => {
  const user = getUserFromReq(req); if(!user) return res.redirect('/auth/login');
  const { name, cpu, ram, tag } = req.body;
  const containerName = `vps-${Date.now()}`;
  // use ubuntu:22.04-based image named zothynodes-vps (built separately)
  const cmd = `docker run -d --name ${containerName} --cpus=${cpu || 0.5} --memory=${(ram||1)}g --env TMATE_CALLBACK_SECRET=${process.env.TMATE_CALLBACK_SECRET} zothynodes/vps:ubuntu22.04`;
  exec(cmd, async (err, stdout, stderr) => {
    if(err){ console.error(err); return res.render('vps_create', { error: 'Docker run failed' }); }
    await VPS.create({ name, ownerId: user.userId, containerName, cpu, ram, tag, status: 'installing' });
    return res.redirect('/vps/list');
  });
});

// actions
router.post('/:id/start', async (req,res)=>{
  const user = getUserFromReq(req); if(!user) return res.redirect('/auth/login');
  const vps = await VPS.findById(req.params.id); if(!vps) return res.redirect('/vps/list');
  exec(`docker start ${vps.containerName}`, (e)=> res.redirect('/vps/list'));
});
router.post('/:id/stop', async (req,res)=>{ const vps = await VPS.findById(req.params.id); exec(`docker stop ${vps.containerName}`, (e)=> res.redirect('/vps/list')); });
router.post('/:id/restart', async (req,res)=>{ const vps = await VPS.findById(req.params.id); exec(`docker restart ${vps.containerName}`, (e)=> res.redirect('/vps/list')); });
router.post('/:id/delete', async (req,res)=>{ const vps = await VPS.findById(req.params.id); exec(`docker rm -f ${vps.containerName}`, async ()=>{ await VPS.deleteOne({ _id: vps._id }); res.redirect('/vps/list'); }); });

module.exports = router;
