const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

router.get('/login', (req,res)=> res.render('login'));
router.get('/register', (req,res)=> res.render('register'));

router.post('/register', async (req,res) => {
  try{
    const { email, password } = req.body;
    const exists = await User.findOne({ email });
    if (exists) return res.render('register', { error: 'Email exists' });
    const hash = await bcrypt.hash(password, 10);
    await User.create({ email, passwordHash: hash });
    return res.redirect('/auth/login');
  }catch(err){
    console.error(err); res.render('register', { error: 'Error' });
  }
});

router.post('/login', async (req,res) => {
  try{
    const { email, password } = req.body;
    const u = await User.findOne({ email });
    if(!u) return res.render('login', { error: 'Invalid' });
    const ok = await bcrypt.compare(password, u.passwordHash || '');
    if(!ok) return res.render('login', { error: 'Invalid' });
    if(u.isBlocked || u.isSuspended) return res.render('login', { error: 'Account restricted' });
    const token = jwt.sign({ userId: u._id, role: u.role }, process.env.JWT_SECRET || 'dev', { expiresIn: '7d' });
    res.cookie('ztoken', token, { httpOnly: true });
    return res.redirect('/vps/list');
  }catch(err){ console.error(err); res.render('login', { error: 'Error' }); }
});

module.exports = router;
