#!/bin/bash
set -e
echo "Installing dependencies..."
if [ ! -f package.json ]; then echo "Run from project root"; exit 1; fi
npm install
echo "Building Docker VPS image (ubuntu22.04)..."
docker build -t zothynodes/vps:ubuntu22.04 ./docker/vps
echo "Done. Create .env from .env.example and run: npm start"
