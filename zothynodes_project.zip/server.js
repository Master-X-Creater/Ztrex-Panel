require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');

const authRoutes = require('./routes/auth');
const vpsRoutes = require('./routes/vps');
const adminRoutes = require('./routes/admin');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/zothynodes')
  .then(()=> console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connect error', err));

app.use('/auth', authRoutes);
app.use('/vps', vpsRoutes);
app.use('/admin', adminRoutes);

// simple home redirect
app.get('/', (req, res) => res.redirect('/auth/login'));

// endpoint for containers to post tmate session (protected by simple secret)
app.post('/vps/ssh-update', async (req, res) => {
  const secret = req.headers['x-tmate-secret'] || req.body.secret;
  if (!secret || secret !== process.env.TMATE_CALLBACK_SECRET) return res.status(403).json({ error: 'forbidden' });
  const { container, ssh, web } = req.body;
  const VPS = require('./models/VPS');
  await VPS.findOneAndUpdate({ containerName: container }, { ssh, sshWeb: web, status: 'online' });
  return res.json({ ok: true });
});

app.listen(PORT, ()=> console.log('ZothyNodes panel listening on port', PORT));
